package a1;

public class Country {
	
	//variables for the country
	private String name;
	private double area;
	private int population;
	private String continent;
	
	//write a constructor for the object, take name,population, area, and continent as parameters.
	public Country(String name, int population, double area, String continent){
		this.name = name;
		this.area = area;
		this.population = population;
		this.continent = continent;
	}
	
	//getter methods for the 4 instance variables
	public String getName(){
		return name;
	}
	
	public String getContinent(){
		return continent;
	}
	
	public double getArea(){
		return area;
	}
	
	public int getPopulation(){
		return population;
	}
	
	//method getPopDensity
	public double getPopDensity(){
		double d;
		d = population / area;
		return d;
	}
	
	//setter method for population
	public void setPopulation(int population){
		this.population = population;
	}
	
	//writeToFile method
	public String writeToFile(){
		String s = getName() + "," + getContinent() + "," + getPopulation() + "," + getPopDensity();
		return s;
	}
	
	//printCountryDetails method
	public void printCountryDetails(){
		String p = getName() + " is located in " + getContinent() + " has a population of " + getPopulation() + " an area of " + getArea() + " and has a population density of " + getPopDensity();
		System.out.println(p);
	}
	
	//toString method
	public String toString(){
		String w = getName() + " in " + getContinent();
		return w;
	}

}
