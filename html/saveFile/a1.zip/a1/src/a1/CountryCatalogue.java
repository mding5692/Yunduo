package a1;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class CountryCatalogue {
	
	//important instance variables
	final int DEFAULT_SIZE = 5;
	final int NOT_FOUND = -1;
	Country[] catalogue = new Country[DEFAULT_SIZE];
	int numOfCountry = 0;
	Set<String> continents = new HashSet<String>();
	Map<String,String> cDict = new HashMap<String,String>();
	
	//constructor
	public CountryCatalogue(String countryInfo, String continentInfo){
		ThingToReadFile countryFile = new ThingToReadFile(countryInfo);
		ThingToReadFile continentFile = new ThingToReadFile(continentInfo);
		//set a value for the first line of continent.txt
		int firstLine = 0;
		//read file from the first line to the last
		while(continentFile.endOfFile() == false){
			//skip the first line
			if (firstLine > 0){
				//read line
				String lineContinent = continentFile.readLine();
				//split the line by ","
				String[] partsCon = lineContinent.split(",");
				String nameCou = partsCon[0];
				String nameContinent = partsCon[1];
				//update the set continents and the map cDict
				continents.add(nameContinent);
				cDict.put(nameCou, nameContinent);
			}
			//number the lines to skip the first line
			firstLine++;
		}
		continentFile.close();
		
		//set a value for the first line of data.txt
		int firstLine1 = 0;
		while(countryFile.endOfFile() == false){
			//read line
			String lineCountry = countryFile.readLine();
			//skip the first line
			if(firstLine1 > 0){
				//split the line by ","
				String[] partsCou = lineCountry.split(",");
				String name = partsCou[0];
				String pop = partsCou[1];
				//convert the population from a string to a integer
				int population = Integer.parseInt(pop);
				String a = partsCou[2];
				//convert the area from string to double
				double area = Double.parseDouble(a);
				String nameCon = cDict.get(name);
				Country c = new Country(name, population, area, nameCon);
				//call the addCatalogue method
				this.addCatalogue(c);
			}
			//number the lines to skip the first line
			firstLine1++;
			
		}
		countryFile.close();
	}
	
	//method to add the provided country to the catalogue.
	private void addCatalogue(Country country){
		
		Country c = country;
		
		//double the size of the catalogue array when the array is full
		if(numOfCountry == catalogue.length){
			expandCapacity();
		}
		catalogue[numOfCountry] = c;
		numOfCountry++;
		
		
	}
	
	//double the size of the catalogue array
	private void expandCapacity() {
		//double the capacity
		Country[] largerList = new Country[catalogue.length*2];
		//move all elements to the new array
		for (int i =0; i < catalogue.length; i++){
			largerList[i] = catalogue[i];
		}
		
		catalogue = largerList;
		
	}
	//add country
	public void addCountry(Country country){
		
		//double the size of the catalogue array when the array is full
		if(numOfCountry == catalogue.length){
			expandCapacity();
		}
		catalogue[numOfCountry] = country;
		numOfCountry++;
		//update the set and the map
		continents.add(country.getContinent());
		cDict.put(country.getName(),country.getContinent());
	}
	
	
	//get country method
	public Country getCountry(int index){
		//print the country with the given index
		if(index < catalogue.length && index >= 0){
			Country s = catalogue[index];
			return s;
		}
		else{
			return null;
		}
	}
	
	//method printCountryCatalogue
	public void printCountryCatalogue(){
		String a = catalogue[0].toString();
		//print all countries in the array
		for(int i=1; i<numOfCountry; i++){
			a = a + "\n" + catalogue[i].toString();
		}
		System.out.println("Country catalogue : ");
		System.out.println(a);
	}
	
	//print all countries from a specified continent
	public void filterCountriesByContinent(String continent){
		String b = "";
		//check every element in the array
		for(int i = 0; i < catalogue.length; i++){
			//check if country is from the specified continent
			if(catalogue[i] != null){
				if(catalogue[i].getContinent().equals(continent)){
					b = b + "\n" + catalogue[i].getName();
				}
			}
		}
		System.out.println("Countries in " + continent + " : ");
		System.out.println(b);
		
	}
	
	//search for a country in the catalogue
	public int searchCatalogue(String name){
		int index = NOT_FOUND;
		String result = "Target country not in catalogue.";
		boolean  found = false;
		//check every element in catalogue
		for(int i = 0;i < catalogue.length && index == NOT_FOUND; i++){
			//check if the name is the same
			if(catalogue[i] != null){
				if (catalogue[i].getName().equals(name)){
					index = i;
					found = true;
				}
			}
		}
		//if not found, print notification
		if (!found){
			System.out.println(result);
		}
		return index;
	}
	
	//remove method
	public void removeCountry(String name){
		int search = NOT_FOUND;
		//search in the array
		if (search == searchCatalogue(name)){
			//if NOT_FOUND, print message
			System.out.println("Target country not in catalogue");
		}
		else{
			//remove target by replacing with the last one in list
			catalogue[searchCatalogue(name)] = catalogue[numOfCountry - 1];
			catalogue[searchCatalogue(name)] = null;
			numOfCountry--;
			//print notification
			System.out.println("Country “" + name + "” has been removed successfully");
		}
	}
	
	//set population for a country
	public void setPopulationOfACountry(String name, int population){
		//search for the country && if not found, print a message
		if (searchCatalogue(name) == NOT_FOUND){
			System.out.println("Target country not in catalogue");
		}
		//if found, set the population and print a message
		else{
			catalogue[searchCatalogue(name)].setPopulation(population);
			System.out.println("The populaiont has been changed successfully");
		}
	}
	
	//write the country to file
	public void saveCountryCatalogue(String filename){
		ThingToWriteFile outFile = new ThingToWriteFile(filename);
		//write each country in a line
		for(int i = 0;i < catalogue.length;i++){
			if(catalogue[i] != null){
				outFile.writeLine(catalogue[i].writeToFile() + "\n");
			}
		}
		//close file when finish writting
		outFile.close();
	}
	
	//find country with the largest population
	public int findCountryWithLargestPop(){
		int largest = 0;
		int index = -1;
		//check every country in the catalogue
		for(int i =0; i < catalogue.length; i++){
			//compare the population
			if(catalogue[i] != null){
				if (largest < catalogue[i].getPopulation()){
					largest = catalogue[i].getPopulation();
					index = i;
				}
			}
		}
		return index;
	}
	
	//find country with the smallest area
	public int findCountryWithSmallestArea(){
		double smallest = catalogue[0].getPopulation();
		int index = -1;
		//check every country in the catalogue
		for(int i =0; i < catalogue.length; i++){
			//compare the population
			if(catalogue[i] != null){
				if (smallest > catalogue[i].getArea()){
					smallest = catalogue[i].getArea();
					index = i;
				}
			}
		}
		return index;
	}
	
	//print out country detail if the country lies within some specified population density range
	public void printCountriesFilterDensity(int rangeL, int rangeH){
		//print the heading
		System.out.println("Countries with a population density between " + rangeH + " and " + rangeL + " : ");
		//check every country in the catalogue
		for (int i = 0; i < catalogue.length; i++){
			//see if the country lies within the range
			if(catalogue[i] != null){
				if (catalogue[i].getPopDensity() <= rangeH && catalogue[i].getPopDensity() >= rangeL){
					//print information of the country that is qualified
					System.out.println(catalogue[i].getName() + " in " + catalogue[i].getContinent() + "\n" + " has a population density of " + catalogue[i].getPopDensity() + ".");
					
				}
			}
		}		
	}
	
	//method to sum up the population of countries within a given continent
	public int sumPop(String continent){
		int pop = 0;
		for(int i = 0; i < catalogue.length; i++){
			//if the country is in the given continent, sum up their populaiton
			if(catalogue[i] != null){
				if(continent.equals(catalogue[i].getContinent())){
					pop = pop + catalogue[i].getPopulation();
				}
			}
		}
		return pop;
	}
	
	//find the most populous continent
	public void findMostPopulousContinent(){
		//get the continent and compare their population
		String con = catalogue[0].getContinent();
		int population = sumPop(catalogue[0].getContinent());
		//every element in the catalogue
		for(int i = 0; i < catalogue.length; i++){
			if(catalogue[i] != null){
				if(population < sumPop(catalogue[i].getContinent())){
					con = catalogue[i].getContinent();
					population = sumPop(con);
				}
			}
		}
		String result = "Continent with the largest population: " + con + "," + " with " + population;
		System.out.println(result);
	}
	

}
